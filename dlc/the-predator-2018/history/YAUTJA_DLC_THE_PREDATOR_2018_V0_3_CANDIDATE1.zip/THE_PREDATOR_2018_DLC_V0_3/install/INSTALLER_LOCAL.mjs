import {cpSync,existsSync,mkdirSync,readFileSync,writeFileSync,rmSync} from 'node:fs';
import {resolve,join,dirname} from 'node:path';
const target=process.argv[2];if(!target){console.error('Usage: node INSTALLER_LOCAL.mjs <repo>');process.exit(2)}
const root=resolve(target),here=resolve(import.meta.dirname,'..');
if(!existsSync(join(root,'package.json'))){console.error('package.json introuvable');process.exit(3)}
const publicDest=join(root,'public','dlc','the-predator-2018');
const routeDest=join(root,'app','dlc','the-predator-2018','page.tsx');
const bridgeDest=join(root,'app','game','dlc','the-predator-2018');
const markerPath=join(publicDest,'.installed-by-the-predator-dlc');
if(existsSync(publicDest)&&!existsSync(markerPath)){console.error('Dossier public/dlc/the-predator-2018 déjà présent et non géré par cet installateur.');process.exit(4)}
if(existsSync(routeDest)&&!readFileSync(routeDest,'utf8').includes('THE_PREDATOR_2018_NATIVE_ROUTE')){console.error('Route app/dlc/the-predator-2018/page.tsx déjà présente et non gérée.');process.exit(5)}
rmSync(publicDest,{recursive:true,force:true});mkdirSync(publicDest,{recursive:true});cpSync(join(here,'web'),publicDest,{recursive:true});
mkdirSync(dirname(routeDest),{recursive:true});cpSync(join(here,'native-integration','app','dlc','the-predator-2018','page.tsx'),routeDest);
rmSync(bridgeDest,{recursive:true,force:true});mkdirSync(bridgeDest,{recursive:true});cpSync(join(here,'native-integration','app','game','dlc','the-predator-2018'),bridgeDest,{recursive:true});
const menu=join(root,'app','game','CampaignMainMenu.tsx'),start='/* THE_PREDATOR_2018_DLC_LINK_START */',end='/* THE_PREDATOR_2018_DLC_LINK_END */';let patched=false;
if(existsSync(menu)){let s=readFileSync(menu,'utf8');if(!s.includes(start)){const anchor='<button type="button" disabled={busy||!catalog||!catalog.slots.some(s=>s.status!==\'empty\')} onClick={()=>open(\'load\')}><span className={styles.actionTitle}>Charger une partie</span>';const at=s.indexOf(anchor);if(at>=0){const close=s.indexOf('</button>',at);if(close>=0){const insert=`\n     ${start}\n     <button type="button" disabled={busy} onClick={()=>{window.location.href='/dlc/the-predator-2018';}}><span className={styles.actionTitle}>DLC · The Predator (2018)</span><small>52 séquences · 183 zones · Humains / Predator</small><span className={styles.actionArrow} aria-hidden="true">›</span></button>\n     ${end}`;s=s.slice(0,close+9)+insert+s.slice(close+9);writeFileSync(menu,s);patched=true}}}else patched=true}
writeFileSync(markerPath,JSON.stringify({version:'0.3.0-candidate.1',patchedMenu:patched,route:'/dlc/the-predator-2018',hostCampaignSlots:false,huntCanvasFusion:false},null,2));
console.log(JSON.stringify({ok:true,version:'0.3.0-candidate.1',publicDest,routeDest,bridgeDest,patchedMenu:patched}));
