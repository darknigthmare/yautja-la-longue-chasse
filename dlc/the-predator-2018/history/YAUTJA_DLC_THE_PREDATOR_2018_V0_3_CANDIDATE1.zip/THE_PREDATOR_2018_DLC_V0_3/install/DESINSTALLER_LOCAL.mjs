import {existsSync,readFileSync,writeFileSync,rmSync} from 'node:fs';import {resolve,join} from 'node:path';
const target=process.argv[2];if(!target){console.error('Usage: node DESINSTALLER_LOCAL.mjs <repo>');process.exit(2)}
const root=resolve(target),publicDest=join(root,'public','dlc','the-predator-2018'),marker=join(publicDest,'.installed-by-the-predator-dlc');
const menu=join(root,'app','game','CampaignMainMenu.tsx'),start='/* THE_PREDATOR_2018_DLC_LINK_START */',end='/* THE_PREDATOR_2018_DLC_LINK_END */';let menuRestored=false;
if(existsSync(menu)){let s=readFileSync(menu,'utf8'),a=s.indexOf(start),b=s.indexOf(end);if(a>=0&&b>a){s=s.slice(0,a)+s.slice(b+end.length);writeFileSync(menu,s);menuRestored=true}}
const route=join(root,'app','dlc','the-predator-2018','page.tsx');if(existsSync(route)&&readFileSync(route,'utf8').includes('THE_PREDATOR_2018_NATIVE_ROUTE'))rmSync(join(root,'app','dlc','the-predator-2018'),{recursive:true,force:true});
const bridge=join(root,'app','game','dlc','the-predator-2018');if(existsSync(join(bridge,'integrationContract.ts'))&&readFileSync(join(bridge,'integrationContract.ts'),'utf8').includes('THE_PREDATOR_2018_NATIVE_BRIDGE'))rmSync(bridge,{recursive:true,force:true});
if(existsSync(marker))rmSync(publicDest,{recursive:true,force:true});
console.log(JSON.stringify({ok:true,menuRestored,removedManagedPublic:!existsSync(publicDest),removedRoute:!existsSync(route)}));
