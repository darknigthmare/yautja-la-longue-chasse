# Intégration v0.3 dans Yautja : La Longue Chasse

## Ce qui est réellement fourni
- route Next.js `app/dlc/the-predator-2018/page.tsx`;
- runtime copié sous `public/dlc/the-predator-2018`;
- manifeste TypeScript `app/game/dlc/the-predator-2018/manifest.ts`;
- contrat d'intégration séparé;
- bouton marqué dans `CampaignMainMenu.tsx`;
- installation et désinstallation réversibles.

## Ce qui n'est pas présenté comme terminé
- aucune fusion directe dans le composant massif `HuntCanvas.tsx`;
- aucun enregistrement dans les cinq slots de campagne hôte;
- aucun remplacement des sprites officiels/host par des assets prétendument 1:1;
- aucun push GitHub ou déploiement Vercel réalisé par cette archive.

La route dédiée est volontaire : elle permet de faire fonctionner le DLC depuis l'application réelle tout en isolant son format de sauvegarde. Une future fusion HuntCanvas devra mapper les 183 micro-zones vers le système de mission natif et convertir les checkpoints sans compromettre les archives existantes.

## Fichiers hôte référencés
Le runtime sait demander les trois arènes V43 déjà existantes pour Stargazer Lab, School Field et Forest Crash. Hors dépôt, ces chemins échouent proprement et le fallback vectoriel autonome est utilisé.
