# Changelog — v0.3.0-candidate.1

## Level design
- Conservation des 52 séquences de la v0.2.
- Conversion en 183 micro-zones avec objectifs locaux.
- Checkpoint par zone, reprise exacte et backtracking sélectif.
- Mini-route de progression visible dans le HUD.

## Combat et IA
- Tirs ennemis à distance et comportement mêlée.
- Jauge d'awareness / détection en furtivité.
- Renforts lorsqu’une infiltration dégénère.
- IA alliée pour les séquences de groupe.
- Esquive humaine, bond Yautja, takedown Predator.
- Loot contextuel : soins, munitions, cellules d'énergie.
- Boss à phases et fenêtres de faiblesse.

## Fidélité
- Fugitive → Upgrade maintenu comme bascule canonique.
- Mort du Fugitive et défaite finale de l’Upgrade verrouillées.
- Emissaries, APC, hybrides et fins alternatives toujours exclus de la campagne cinéma.

## Sauvegarde
- Nouvelle clé `yautja.dlc.the-predator-2018.v3`.
- Migration automatique de la progression v0.2.
- Fallback mémoire si le stockage navigateur est indisponible.

## Intégration
- Route Next.js `/dlc/the-predator-2018`.
- Manifeste TypeScript des 52 scènes.
- Contrat d’intégration déclarant explicitement que les slots hôte et HuntCanvas ne sont pas encore fusionnés.
- Installateur/désinstallateur réversibles testés sur fixture.

## QA
- 52/52 tests Node.
- 52/52 scènes ouvertes dans Chromium.
- 5/5 scénarios d'interaction navigateur (contrôles Humains/Predator, transition+checkpoint, stockage bloqué, migration v0.2).
- 0 erreur runtime navigateur.
