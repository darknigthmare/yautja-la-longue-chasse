# Systèmes gameplay v0.3

Cette version remplace le principe « une scène = un écran » par des parcours composés. Les routes font entre 2 et 5 micro-zones et conservent le même événement narratif. Chaque zone a son objectif local, son budget d'ennemis et un checkpoint.

## Exploration
Le joueur traverse plusieurs pièces/plans, peut revenir dans les zones qui l'autorisent et reprend dans la micro-zone confirmée plutôt qu'au début de la séquence. Les décors exposent plusieurs plans latéraux, des portes/seuils et une mini-route dans le HUD.

## Humains
Munitions et rechargement sont séparés, l'esquive donne une brève fenêtre d'invulnérabilité et les compagnons engagés dans la scène peuvent combattre. Les armes varient selon la séquence : sniper, fusil, shotgun, pistolet, lance-grenades et technologie récupérée.

## Predator
Le camouflage consomme de l'énergie, la vision facilite la lecture des cibles, l'impulsion de gant apporte un contrôle rapproché et le takedown récompense l'approche furtive. Le Fugitive et l'Upgrade n'utilisent pas un simple skin commun : leurs phases, armes et contraintes sont décrites séparément dans les données.

## Boss et verrouillage canonique
Les combats de boss utilisent plusieurs phases et fenêtres de vulnérabilité. Une scène de type `scripted-loss` conserve l'issue du montage : le système ne transforme pas une performance parfaite du joueur en histoire alternative.

## Sauvegarde
`yautja.dlc.the-predator-2018.v3` enregistre campagne, scène, micro-zone, progression, difficulté et déblocages. Une progression v0.2 trouvée peut être migrée vers la première micro-zone de la scène correspondante.
