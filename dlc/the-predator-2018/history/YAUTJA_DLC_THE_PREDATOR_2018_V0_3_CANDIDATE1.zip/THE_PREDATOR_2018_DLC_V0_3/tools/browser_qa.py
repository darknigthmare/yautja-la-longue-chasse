#!/usr/bin/env python3
import base64, json, pathlib, shutil, subprocess, sys, time
import requests, websocket
ROOT=pathlib.Path(__file__).resolve().parents[1]; OUT=ROOT/'docs'; CAPS=OUT/'captures'; CAPS.mkdir(parents=True,exist_ok=True)
DEBUG=9444; BASE=(ROOT/'JOUER_THE_PREDATOR_2018_V0_3.html').read_text()
TOKEN="window.__TP_QA_QUERY=window.__TP_QA_QUERY||'';"

def wait_http(url, timeout=8):
    end=time.time()+timeout
    while time.time()<end:
        try:
            r=requests.get(url,timeout=.35)
            if r.ok:return r
        except Exception: pass
        time.sleep(.08)
    raise RuntimeError(f'HTTP indisponible: {url}')

def cdp(ws):
    seq=0
    def call(method,params=None):
        nonlocal seq;seq+=1;ident=seq
        ws.send(json.dumps({'id':ident,'method':method,'params':params or {}}))
        while True:
            msg=json.loads(ws.recv())
            if msg.get('id')==ident:
                if 'error' in msg: raise RuntimeError(msg['error'])
                return msg.get('result',{})
    return call

def new_page(query='', prelude=''):
    info=requests.put(f'http://127.0.0.1:{DEBUG}/json/new?about:blank',timeout=2).json()
    ws=websocket.create_connection(info['webSocketDebuggerUrl'],timeout=5);call=cdp(ws);call('Page.enable');call('Runtime.enable')
    frame=call('Page.getFrameTree')['frameTree']['frame']['id']
    html=BASE.replace(TOKEN,'window.__TP_QA_QUERY='+json.dumps('?'+query if query else '')+';'+prelude)
    call('Page.setDocumentContent',{'frameId':frame,'html':html})
    return info,ws,call

def close_page(info,ws):
    try: ws.close()
    except Exception: pass
    try: requests.get(f"http://127.0.0.1:{DEBUG}/json/close/{info['id']}",timeout=1)
    except Exception: pass

def evaluate(call,expr):
    r=call('Runtime.evaluate',{'expression':expr,'returnByValue':True,'awaitPromise':True})
    return r.get('result',{}).get('value')

def wait_ready(call,scene=None,timeout=2.5):
    end=time.time()+timeout;last=None
    while time.time()<end:
        last=evaluate(call,"({scene:document.documentElement.dataset.qaScene||'',room:Number(document.documentElement.dataset.qaRoom||-1),screen:document.documentElement.dataset.qaScreen||'',campaign:document.documentElement.dataset.qaCampaign||'',runtimeError:document.documentElement.dataset.runtimeError||'',errors:window.__TP_QA?.errors||[],ready:document.readyState})")
        if last and last.get('ready')=='complete' and window_ready(last,scene): return last
        time.sleep(.05)
    return last

def window_ready(info,scene):
    if not info:return False
    if info.get('runtimeError') or info.get('errors'):return True
    return bool(info.get('scene')) if scene else bool(info.get('screen'))

def shot(call,path):
    r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});path.write_bytes(base64.b64decode(r['data']))

def key(call,code,hold=.04):
    keyname={'Space':' ','ArrowRight':'ArrowRight','ArrowLeft':'ArrowLeft','ArrowUp':'ArrowUp','ArrowDown':'ArrowDown','ShiftLeft':'Shift','KeyC':'c','KeyV':'v','KeyT':'t','KeyF':'f','KeyR':'r'}.get(code,code)
    call('Input.dispatchKeyEvent',{'type':'keyDown','code':code,'key':keyname});time.sleep(hold);call('Input.dispatchKeyEvent',{'type':'keyUp','code':code,'key':keyname})

def main():
    chrome=None
    try:
        profile='/tmp/tp2018-v03-chrome';shutil.rmtree(profile,ignore_errors=True)
        chrome=subprocess.Popen(['chromium','--headless=new','--no-sandbox','--disable-gpu','--disable-dev-shm-usage','--no-first-run',f'--remote-debugging-port={DEBUG}','--remote-allow-origins=*',f'--user-data-dir={profile}','--window-size=1440,900','about:blank'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        wait_http(f'http://127.0.0.1:{DEBUG}/json/version')
        data=json.loads((ROOT/'src/data/game-data.json').read_text());results=[]
        for camp in ('human','predator'):
            for i,s in enumerate(data['campaigns'][camp]['scenes']):
                room=max(0,len(s['route'])-1);info=ws=call=None
                try:
                    info,ws,call=new_page(f'qa=scene&campaign={camp}&i={i}&room={room}')
                    qa=wait_ready(call,s['id']);ok=bool(qa and qa['scene']==s['id'] and qa['room']==room and not qa['runtimeError'] and not qa['errors'])
                    results.append({'campaign':camp,'scene':s['id'],'room':room,'ok':ok,'info':qa})
                    if not ok:print('FAIL',camp,s['id'],room,qa)
                finally:
                    if info:close_page(info,ws)
        interactions=[]
        info,ws,call=new_page('qa=scene&campaign=predator&i=6&room=1');wait_ready(call,'P07')
        for code in ('KeyC','KeyV','ShiftLeft','KeyT','KeyF','Space'):key(call,code)
        pred=evaluate(call,"({error:document.documentElement.dataset.runtimeError||'',errors:window.__TP_QA?.errors||[],scene:document.documentElement.dataset.qaScene,room:document.documentElement.dataset.qaRoom})")
        interactions.append({'name':'predator-controls','ok':not pred['error'] and not pred['errors'],'info':pred});close_page(info,ws)
        info,ws,call=new_page('qa=scene&campaign=human&i=7&room=1');wait_ready(call,'H08')
        for code in ('ShiftLeft','Space','KeyR','ArrowUp','ArrowDown'):key(call,code)
        hum=evaluate(call,"({error:document.documentElement.dataset.runtimeError||'',errors:window.__TP_QA?.errors||[],scene:document.documentElement.dataset.qaScene,room:document.documentElement.dataset.qaRoom})")
        interactions.append({'name':'human-controls','ok':not hum['error'] and not hum['errors'],'info':hum});close_page(info,ws)
        # Transition + checkpoint. The scene has no enemies in its first zone.
        info,ws,call=new_page('qa=scene&campaign=human&i=1&room=0');wait_ready(call,'H02')
        call('Input.dispatchKeyEvent',{'type':'keyDown','code':'ArrowRight','key':'ArrowRight'});time.sleep(6.4);call('Input.dispatchKeyEvent',{'type':'keyUp','code':'ArrowRight','key':'ArrowRight'});time.sleep(.15)
        transition=evaluate(call,"({room:Number(document.documentElement.dataset.qaRoom||-1),checkpointRoom:Number(document.documentElement.dataset.qaCheckpointRoom||-1),error:document.documentElement.dataset.runtimeError||'',errors:window.__TP_QA?.errors||[]})")
        tok=bool(transition and transition['room']>=1 and transition['checkpointRoom']>=1 and not transition['error'] and not transition['errors'])
        interactions.append({'name':'room-transition-checkpoint','ok':tok,'info':transition});close_page(info,ws)
        # localStorage unavailable: safeStore must keep the DLC usable through its in-memory fallback.
        info,ws,call=new_page('qa=scene&campaign=human&i=0&room=0', "Object.defineProperty(window,'localStorage',{configurable:true,get(){throw new Error('qa-storage-blocked')}});")
        blocked=wait_ready(call,'H01');storage_ok=bool(blocked and blocked.get('scene')=='H01' and not blocked.get('runtimeError') and not blocked.get('errors'))
        interactions.append({'name':'storage-blocked-fallback','ok':storage_ok,'info':blocked});close_page(info,ws)
        # Migration v0.2 -> v0.3: exercise the real migration function in the runtime.
        info,ws,call=new_page('qa=menu');wait_ready(call,None)
        migration=evaluate(call,"(()=>{try{const q=window.__TP_QA;q.storageDel(q.saveKey);q.storageSet(q.legacyKey,JSON.stringify({human:{unlocked:9,last:7,checkpoint:{scene:7,hp:73,energy:61,ammo:5},clues:['legacy'],honors:['old']}}));const migrated=q.migrateLegacy();const p=q.progress();return {migrated,scene:p.human?.checkpoint?.scene,room:p.human?.checkpoint?.room,hp:p.human?.checkpoint?.hp,honors:p.human?.honors||[],error:document.documentElement.dataset.runtimeError||'',errors:q.errors||[]}}catch(e){return {migrated:false,error:String(e),errors:[]}}})()")
        mig_ok=bool(migration and migration.get('migrated') and migration.get('scene')==7 and migration.get('room')==0 and migration.get('hp')==73 and 'old' in migration.get('honors',[]) and not migration.get('error') and not migration.get('errors'))
        interactions.append({'name':'legacy-save-migration','ok':mig_ok,'info':migration});close_page(info,ws)
        visual=[('menu','menu.png'),('human','human-multizone.png'),('fugitive','fugitive.png'),('upgrade','upgrade.png'),('final','human-final-boss.png'),('pred-final','predator-final.png'),('timeline','timeline.png'),('systems','systems.png')]
        for q,name in visual:
            info,ws,call=new_page(f'qa={q}');wait_ready(call,None);time.sleep(.12);shot(call,CAPS/name);close_page(info,ws)
        all_ok=all(r['ok'] for r in results) and all(x['ok'] for x in interactions)
        report={'version':'0.3.0-candidate.1','scenesChecked':len(results),'scenesPassed':sum(r['ok'] for r in results),'interactions':interactions,'visualCaptures':[name for _,name in visual],'runtimeErrors':sum(0 if r['ok'] else 1 for r in results),'ok':all_ok}
        (OUT/'BROWSER_QA_RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2));return 0 if all_ok else 1
    finally:
        if chrome and chrome.poll() is None:
            chrome.terminate()
            try:chrome.wait(timeout=3)
            except subprocess.TimeoutExpired:chrome.kill()
if __name__=='__main__':raise SystemExit(main())
