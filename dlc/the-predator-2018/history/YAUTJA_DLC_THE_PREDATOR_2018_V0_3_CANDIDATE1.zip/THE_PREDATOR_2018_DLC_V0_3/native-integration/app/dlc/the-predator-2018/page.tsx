/* THE_PREDATOR_2018_NATIVE_ROUTE */
export const metadata = {
  title: "The Predator (2018) · Chasse croisée",
  description: "DLC cinéma à deux campagnes pour Yautja : La Longue Chasse.",
};

export default function ThePredator2018Page() {
  return (
    <main style={{ width: "100vw", height: "100svh", margin: 0, background: "#010403" }}>
      <iframe
        title="The Predator 2018 — Chasse croisée"
        src="/dlc/the-predator-2018/index.html"
        style={{ width: "100%", height: "100%", border: 0, display: "block" }}
        allow="fullscreen"
      />
    </main>
  );
}
