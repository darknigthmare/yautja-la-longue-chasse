/* THE_PREDATOR_2018_NATIVE_BRIDGE */
export const THE_PREDATOR_2018_INTEGRATION_CONTRACT = {
  route: "/dlc/the-predator-2018",
  saveKey: "yautja.dlc.the-predator-2018.v3",
  hostCampaignSlots: false,
  huntCanvasFusion: false,
  hostAssets: [
    "/game/sprites/v43/pit-arenas/arena-110-the-predator-2018-stargazer-lab/p0-depth.png",
    "/game/sprites/v43/pit-arenas/arena-111-the-predator-2018-school-field/p0-depth.png",
    "/game/sprites/v43/pit-arenas/arena-112-the-predator-2018-forest-crash/p0-depth.png",
  ],
} as const;

/**
 * v0.3 bridge contract.
 * The route is native to the Next.js host, but the playable runtime remains isolated
 * from HuntCanvas and from the five main campaign save slots.
 */
export type ThePredator2018IntegrationContract =
  typeof THE_PREDATOR_2018_INTEGRATION_CONTRACT;
