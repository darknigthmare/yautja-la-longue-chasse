# THE PREDATOR — CHASSE CROISÉE

## v0.3.0-candidate.1

DLC fan-made autonome pour **Yautja : La Longue Chasse**, construit autour du montage cinéma de *The Predator* (2018). Cette candidate conserve les **52 séquences** de la v0.2 — **26 Humains + 26 Predator** — et les transforme en véritables parcours 2D multi-zones.

### Contenu jouable

- **183 micro-zones** réparties sur 18 lieux/variantes.
- Campagne Humains : Quinn McKenna comme fil principal, avec Rory, Casey et les Loonies selon la chronologie.
- Campagne Predator : Fugitive Predator jusqu’à son issue canonique, puis Upgrade Predator.
- Checkpoint dans chaque micro-zone et reprise dans la pièce exacte.
- Backtracking sur les zones compatibles, changements de plan, passages par portes et seuils.
- Combat à distance et mêlée, rechargement, loot, esquive humaine / bond Yautja.
- Camouflage, vision Predator, énergie, impulsion de gant et takedown.
- IA compagnon et tirs ennemis à distance.
- Boss à phases et fenêtres de faiblesse.
- Issues canoniques verrouillées pour éviter les fins alternatives accidentelles.
- Sauvegarde v3 indépendante, avec migration automatique de la progression v0.2.

### Intégration La Longue Chasse

Le dossier `native-integration/` fournit une passerelle Next.js et un manifeste TypeScript. L’installateur copie le runtime dans `public/dlc/the-predator-2018`, crée la route `/dlc/the-predator-2018`, installe le bridge de données et ajoute un bouton au menu Campagne. La désinstallation enlève uniquement ce que le pack a marqué comme lui appartenant.

Cette candidate **ne prétend pas encore** fusionner les états internes de `HuntCanvas` ni les cinq slots de campagne du jeu principal : les sauvegardes du DLC restent isolées pour éviter toute corruption.

### Décors

Quand le DLC tourne depuis le dépôt hôte, il peut réutiliser les trois décors V43 déjà présents pour Stargazer Lab, School Field et Forest Crash. Le standalone utilise des graphismes vectoriels originaux de remplacement. Aucun photogramme ou pixel officiel du film n’est inclus.

### Installation locale

```bash
node install/INSTALLER_LOCAL.mjs /chemin/vers/yautja-la-longue-chasse
```

Pour retirer le DLC :

```bash
node install/DESINSTALLER_LOCAL.mjs /chemin/vers/yautja-la-longue-chasse
```

### Commandes

- Q/D ou ←/→ : déplacement horizontal
- Z/S ou ↑/↓ : changement de plan
- Espace : attaque
- R : recharge
- E : interaction / porte
- Maj : esquive humaine / bond Yautja
- C : camouflage Predator
- V : vision Predator
- F : impulsion Predator
- T : takedown Predator
- M : sélection de chapitres
- P : pause

### Validation

- Node : **52/52** contrôles réussis.
- Chromium : **52/52** séquences chargées.
- Interactions : **5/5** scénarios de contrôle réussis.
- Erreurs runtime Chromium : **0**.

Voir `docs/RAPPORT_VISUEL_QA_V0_3.html` pour les captures réelles et `docs/INTEGRATION_V0_3.md` pour les limites exactes de la passerelle native.
