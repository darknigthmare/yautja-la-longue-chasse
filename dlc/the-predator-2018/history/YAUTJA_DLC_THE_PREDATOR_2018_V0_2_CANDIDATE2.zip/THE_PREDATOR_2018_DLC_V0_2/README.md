# THE PREDATOR — CHASSE CROISÉE · v0.2.0-candidate.2

DLC prototype autonome pour **Yautja : La Longue Chasse**, fondé sur le montage cinéma de *The Predator* (2018).

## Contenu

- 26 séquences **Humains** : Quinn, Rory, Casey et les Loonies.
- 26 séquences **Predator** : Fugitive Predator puis Upgrade Predator.
- 18 lieux/variantes de scènes, jusqu’à 3 plans jouables par scène.
- combats, boss, survie, défense, scan, interaction, furtivité, camouflage, vision Predator, énergie, munitions/rechargement.
- progression locale robuste avec fallback mémoire si `localStorage` est bloqué.
- chronologie miroir E00–E26, codex, personnages, arsenal et sélection de chapitres.
- trois difficultés ; elles modifient uniquement les dégâts, jamais les événements du film.
- réutilisation optionnelle des 3 décors V43 déjà présents dans le projet hôte : Stargazer Lab, School Field, Forest Crash.

## Lancer immédiatement

Ouvrir `JOUER_THE_PREDATOR_2018_V0_2.html`, ou `web/index.html`.

## Installer dans une copie locale de La Longue Chasse

```bash
node install/INSTALLER_LOCAL.mjs /chemin/vers/yautja-la-longue-chasse
```

L’installateur copie le DLC vers `public/dlc/the-predator-2018/` et tente d’ajouter un bouton dans `CampaignMainMenu.tsx` entre marqueurs réversibles. Si l’ancre attendue a changé, la copie du DLC reste installée mais le menu hôte n’est pas modifié.

Désinstallation :

```bash
node install/DESINSTALLER_LOCAL.mjs /chemin/vers/yautja-la-longue-chasse
```

## Contrôles

- Q/D, A/D ou ←/→ : déplacement latéral
- Z/S, W/S ou ↑/↓ : changer de plan
- Espace : attaque
- E : action / scan
- R : recharger
- Predator : C camouflage, V vision, F impulsion de gant
- M : chapitres
- P : pause
- Échap : menu

## Fidélité

Le pack vise la fidélité **chronologique, événementielle, de rôle et d’équipement** au montage cinéma. Il ne copie ni les dialogues ni les plans du film, et ne redistribue pas d’images officielles. Le contenu supprimé (Emissaries, APC, menagerie, fins Ripley/Newt) est documenté séparément et n’est pas mélangé à la campagne canon du montage.
