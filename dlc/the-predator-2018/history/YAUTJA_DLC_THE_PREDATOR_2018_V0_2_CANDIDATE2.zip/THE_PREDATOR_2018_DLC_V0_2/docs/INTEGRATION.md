# Intégration à Yautja : La Longue Chasse

## Mode sûr

L’installateur ne remplace aucun système de sauvegarde principal. Le DLC est servi depuis `public/dlc/the-predator-2018/`.

## Décors réutilisés

Quand ces chemins existent dans le projet hôte, le runtime tente de charger :

- `/game/sprites/v43/pit-arenas/arena-110-the-predator-2018-stargazer-lab/p0-depth.png`
- `/game/sprites/v43/pit-arenas/arena-111-the-predator-2018-school-field/p0-depth.png`
- `/game/sprites/v43/pit-arenas/arena-112-the-predator-2018-forest-crash/p0-depth.png`

Le rendu vectoriel interne sert de fallback.

## Prochaine fusion native

Pour une fusion dans `HuntCanvas`, garder les identifiants de scène et d’événement de `src/data/game-data.json`. Ils sont conçus comme contrat de migration.
