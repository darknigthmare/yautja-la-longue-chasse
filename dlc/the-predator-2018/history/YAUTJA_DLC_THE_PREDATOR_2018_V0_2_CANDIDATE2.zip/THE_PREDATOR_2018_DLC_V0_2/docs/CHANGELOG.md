# Changelog

## 0.2.0-candidate.2 — 29 septembre 2026

- passage de 35 à **52 séquences** : 26 Humains + 26 Predator ;
- séparation jouable Fugitive → Upgrade ;
- 18 lieux/variantes et jusqu’à trois plans ;
- munitions, recharge, énergie Predator, camouflage, vision et impulsion ;
- ennemis par plan, compagnons visuels et props thématiques ;
- trois difficultés sans bifurcation narrative ;
- chronologie miroir E00–E26 ;
- codex personnages/armes/fidélité ;
- fallback mémoire si `localStorage` est indisponible ;
- installateur/désinstallateur avec patch de menu réversible ;
- 3 chemins de décors V43 du projet hôte réutilisables ;
- 24 tests Node, 52/52 chargements de scènes Chromium, 8/8 tests d’interaction Chromium, 6 captures de référence sans erreur console/page.

Base d’intégration vérifiée : `main` 3d8efbcfb42939a33093ee3ad923c0e97ff53ff5 (contenu V54).
