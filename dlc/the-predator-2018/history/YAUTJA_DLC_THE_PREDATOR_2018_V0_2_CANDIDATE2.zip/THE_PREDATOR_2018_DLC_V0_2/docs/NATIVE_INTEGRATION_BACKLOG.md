# Backlog de fusion native

1. Convertir les 52 séquences en définitions de missions `HuntCanvas` sans changer leurs IDs E00–E26.
2. Brancher les checkpoints sur les slots de campagne V54 et conserver la clé autonome comme import optionnel.
3. Remplacer les silhouettes par sprites atomiques validés Fugitive / Upgrade / humains / hounds.
4. Réutiliser nativement les trois arènes V43 et produire les autres décors sous le pipeline d’assets du projet.
5. Ajouter cinématiques originales de liaison sans recopier le montage ni les dialogues du film.
6. Faire un mode bonus séparé `Deleted Cut` désactivé par défaut pour Emissaries/APC/menagerie, sans l’étiqueter canon.
7. Ajouter QA manette/mobile et sauvegarde réelle dans la branche du projet avant publication.
