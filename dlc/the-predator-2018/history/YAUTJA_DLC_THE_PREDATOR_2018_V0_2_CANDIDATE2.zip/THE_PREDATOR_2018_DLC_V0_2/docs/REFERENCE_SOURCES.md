# Références de vérification

## R1 — The Predator (2018) — plot summary

- URL : https://en.wikipedia.org/wiki/The_Predator_(film)
- Usage : Ordre général des événements du montage cinéma.

## R2 — Fugitive Predator — AVP Galaxy

- URL : https://www.avpgalaxy.net/predator/fugitive/
- Usage : Actions, équipement et déroulé du Fugitive dans le montage.

## R3 — Upgrade Predator — AVP Galaxy

- URL : https://www.avpgalaxy.net/predator/upgrade/
- Usage : Actions, capacités, équipements et chasse finale de l’Upgrade.

## R4 — The Predator Reshoots — AVP Galaxy

- URL : https://www.avpgalaxy.net/2018/07/06/avpgalaxy-exclusive-the-predator-reshot-3rd-act-details/
- Usage : Séparation montage cinéma / troisième acte supprimé.

## R5 — Deleted Scenes & Alternate Endings — AVP Galaxy

- URL : https://www.avpgalaxy.net/predator-movies/predator-4/deleted-scenes/
- Usage : Backlog explicite du contenu retiré.

