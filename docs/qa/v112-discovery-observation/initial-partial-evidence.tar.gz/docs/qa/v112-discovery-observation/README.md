# ECO112-11 — causes observées et limites de lecture

Cette qualification reste **partielle**. Les états de deux vrais parcours GameClient contiennent 11 découvertes visuelles de corps, trois mises en attente radio et des ordres locaux d'investigation. Ils ne contiennent **aucun reçu radio** et ne démontrent aucune compréhension humaine. Un ordre d'investigation n'établit pas à lui seul que la poursuite du chasseur a été remplacée.

Source : `e4a6c64a1e77edad8865aa05ca7c2901d62bfa09`. [Observations et empreintes](observations.json). Les journaux navigateur originaux sont conservés sans modification en [jungle](browser-samples-0.json.gz) et [glace](browser-samples-1.json.gz), avec leurs SHA256 avant et après compression. Le premier parcours termine jungle ; le second reste un essai glace échoué. Ces résultats ne sont pas fusionnés en succès de campagne.

```sh
node --experimental-strip-types scripts/qa-hunt-discovery-observations-v112.mjs
```

Le script lit les journaux terminés autorisés par leur agent propriétaire. Il ne lance aucune simulation, ne rejoue aucun état, ne place aucun acteur/corps et ne fabrique aucune capture.

## Ce que montrent les données

| Parcours réel | Échantillons | Reçus visuels uniques | Reçus radio | Files radio observées | Candidats badge humain dans le bitmap |
| --- | ---: | ---: | ---: | ---: | ---: |
| Jungle terminée | 65 | 4 | 0 | 1 | 2 |
| Glace, essai échoué | 66 | 7 | 0 | 2 | 21 |

Un candidat signifie seulement que le rectangle natif du badge tient dans les 1280×720 du Canvas après transformation caméra. Ce calcul ne prouve pas qu'une image de ce moment a été capturée, qu'un autre élément ne le recouvrait pas ou qu'un humain l'a compris.

- Jungle, indice 14 (indices JSON à partir de zéro), t=14,10 s : jungle-patrol-1 reçoit la découverte visuelle du corps jungle-patrol-3 à14,0167 s. Sa réaction investigate reste active jusqu'à21,0167 s et un ordre riteInvestigate vise le corps. Une émission est planifiée à14,8167 s, soit +0,8 s. Aucun destinataire radio n'apparaît ensuite dans ce ledger.
- Glace, indice 23, t=32,45 s : ice-brutes-0 porte une réaction visual/investigate liée au corps ice-salvagers-1 et un ordre vers sa position. Son mode IA est cover ; cela empêche de prétendre qu'il enquête effectivement à la place de toute autre action.
- Glace, indices 61→62, t=75,15→76,45 s : ice-brutes-1 passe de engage à search. Au second échantillon lostContactSeconds vaut déjà0, donc les relevés ne démontrent pas la latence exacte de perte de contact. Aucun couple adjacent de ces journaux ne réunit engage précédent et search courant avec lostContactSeconds≥1,4.

La [capture native de glace](native-ice-animal-avoidance.png), inspectée telle quelle, montre le badge « ÉVITEMENT » avec la patte. C'est une réponse animale ; elle n'est pas présentée comme vision humaine, réception radio ou recherche humaine après perte du chasseur. Elle provient du même vrai essai glace, sans rendu de substitution.

## Discriminants réellement implémentés

| Cause | État observable nécessaire | Rendu ou limite |
| --- | --- | --- |
| Corps vu | receipt.channel=visual, corpseId/actorId, sourceActorId=null ; réaction actuelle investigate | Œil + « CORPS REPÉRÉ » au-dessus du témoin vivant et actif. La capture doit montrer ce badge à cet instant. |
| Radio reçue | receipt.channel=radio avec sourceActorId distinct, reçu visuel antérieur chez la source, réception différée ; réaction actuelle encore radio | Antenne/ondes + « RADIO · CORPS ». Une file pending seule ne prouve ni réception ni badge. Une découverte visuelle au même tick peut remplacer cette réaction. |
| Investigation du corps | enemy.riteInvestigate et réaction du même corpseId, puis déplacement du témoin vers le corps | Les contacts sensoriels locaux déterminent si cet ordre prend priorité ; ils ne sont pas sérialisés dans les états fournis. Ordre et déplacement doivent être distingués. |
| Recherche du chasseur perdu | Séquence temporelle engage→search, lostContactSeconds et lastKnownTarget, positions du joueur et du témoin | search peut aussi venir d'une suspicion ou d'une alerte. Aucun texte Canvas propre à cette cause n'est trouvé ; le son enemy-alert est partagé. |
| Réponse animale | response=avoid/inspect/guard | Patte et « ÉVITEMENT », « EXAMEN » ou « GARDE ». Le label choisit la réponse avant le canal : il n'identifie pas à lui seul vision ou odeur. |

La chaîne du corps est updateCorpseDiscoveryV112 → ecosystem.receipts/reactions/pendingRadios → drawDiscoverySignalV112. Le délai radio source vaut 0,8 s, la réaction 7 s et la portée radio 480 unités ; les valeurs sont des réglages du jeu. L'IA de poursuite/perte du chasseur est un moteur distinct.

## Critères pour compléter la preuve

Une capture opportune doit conserver le corps, le témoin et le badge réellement actif, puis le reçu et la réaction de la même lecture d'état. Pour la radio, conserver source et destinataire distincts ainsi que l'émission puis la réception ; un badge animal ou une émission sans réception ne convient pas. Pour l'investigation, suivre le mouvement réel et établir la priorité des contacts ; un état search isolé ne convient pas.

Aucun statut de compréhension humaine n'est accordé. ECO112-11 reste à compléter pour la réception radio capturée, l'attribution sans ambiguïté de l'investigation/recherche et la lecture par des joueurs. Les fichiers applicatifs, assets et anciens rapports sont inchangés.
